#pragma once
#include<bits/stdc++.h>
#include<regex>

using namespace std;

class Node{
	int id_number;
	string id;
	bool border_node;
	static int count;
	vector<pair<int, int>> edges;

public:
	static int get_count(){
		return Node::count;
	}

	int get_id_number() const{
		return id_number;
	}

	string get_id() const{
		return id;
	}

	vector<pair<int, int> > get_edges() const{
		return edges;
	}

	Node(string id, bool border_node): id(id), border_node(border_node) {
		id_number = Node::count++;
	}

	void add_edge(Node x, int cost){
		edges.emplace_back(x.get_id_number(), cost);
	}

	static bool can_connect(Node a, Node b){
		return a.border_node && b.border_node;
	}

	static bool not_included_in_AS(vector<Node> nodes, string given_id){
		for (const auto& node: nodes){
			if (node.id == given_id)
				return false;
		}
		return true;
	}

	~Node() = default;
};

int Node::count = 0;

class Galaxy{ 
	string id;
	vector<Node> nodes;
	map<int, string> id_number_to_id;
	int get_idx(string id){
		int idx;
		for (idx=0; idx < nodes.size(); idx++){
			if (nodes[idx].get_id()==id){
				return idx;
			}
		}
		return -1;
	}
public:
	Galaxy() {}
	Galaxy(string id): id(id){}

	void add_node(string id, bool border_node){
		if (Node::not_included_in_AS(nodes, id)){
			Node new_node(id, border_node);
			nodes.push_back(new_node);
			id_number_to_id[new_node.get_id_number()] = id;
		}
		else
			cout << "the node with given id does exist in the gievn As, please try again\n";
	}

	Node get_node(string id){
		return nodes[get_idx(id)];
	}

	void add_edge(string id_a, Node b, int cost){
		int idx = get_idx(id_a);
		nodes[idx].add_edge(b, cost);
	}

	int get_id_number(string id){
		int idx = get_idx(id);
		return nodes[idx].get_id_number();
	}

	pair<vector<int>, vector<Node>> get_all_nodes() const{
		vector<int> id_numbers;
		for (Node node: nodes){
			id_numbers.push_back(node.get_id_number());
		}
		return make_pair(id_numbers, nodes);
	}

	bool galaxy_contains_node(int id_number){ // added to see if certain is present in map
		auto it = id_number_to_id.find(id_number);
		return it != id_number_to_id.end(); 
	}

	string get_id_by_id_number(int id_number){
		return id_number_to_id[id_number];
	}

	static pair<string, string> get_ids(unordered_map<string, Galaxy> galaxies, int id_number){ // added to get galaxy_id and node_id by its id_number
		for (auto [galaxy_id, galaxy]: galaxies){
			if (galaxy.galaxy_contains_node(id_number)){
				return make_pair(galaxy_id, galaxy.get_id_by_id_number(id_number));
			}
		}
		return make_pair("not found", "not found");
	}

	~Galaxy() = default;
};

class Universe{
	unordered_map<string, Galaxy> galaxies;
	vector<vector<int>> matrix; // modified
public:
	Universe(){}

	void add_galaxy(string id){
		Galaxy galaxy(id);
		galaxies[id] = galaxy;
	}

	void add_node(string id, bool border_node, string AS_id){ 
		galaxies[AS_id].add_node(id, border_node);
	}

	void add_edge(string galaxy_a, string node_a, string galaxy_b, string node_b, int cost){ 
		Node a = galaxies[galaxy_a].get_node(node_a);
		Node b = galaxies[galaxy_b].get_node(node_b);

		if ((galaxy_a == galaxy_b || Node::can_connect(a, b)) && cost > 0){
			galaxies[galaxy_a].add_edge(node_a, b, cost);
			galaxies[galaxy_b].add_edge(node_b, a, cost);
		}
		else{
			cout << "the two given nodes cant be connected, please try again\n";
		}
	}

	void update_costs_matrix(){ // modified
		int INF = 1e9;	
		matrix.clear();
		int v = Node::get_count();
		matrix.resize(v, vector<int>(v, INF));
		for (auto iter: galaxies){
			auto galaxy = iter.second;
			auto [id_numbers, galaxy_nodes] = galaxy.get_all_nodes();

			for (int i=0; i < galaxy_nodes.size(); i++){
				int place_a = id_numbers[i];
				for (pair<int, int> edge: galaxy_nodes[i].get_edges()){
					matrix[place_a][edge.first] = edge.second;
					matrix[edge.first][place_a] = edge.second;
				}
			}
		}
	}

	void show_travel_cost(string galaxy_a, string id_a, string galaxy_b, string id_b){ // modified
		int INF = 1e9;	
		int v = Node::get_count();
		update_costs_matrix();

		int source =  galaxies[galaxy_a].get_id_number(id_a);
		int target =  galaxies[galaxy_b].get_id_number(id_b);

		int n = matrix.size();
	    vector<int> dist(n, INF);
	    vector<int> parent(n, -1); 

	    dist[source] = 0;
	    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
	    pq.push({0, source});

	    while (!pq.empty()) {
	        int u = pq.top().second;
	        pq.pop();

	        if (u == target)
	            break;

	        for (int v = 0; v < n; ++v) {
	            if (matrix[u][v] != INF && dist[v] > dist[u] + matrix[u][v]) {
	                dist[v] = dist[u] + matrix[u][v];
	                parent[v] = u; 
	                pq.push({dist[v], v});
	            }
	        }
	    }

	    if (parent[target] == -1) {
	        cout << "No path from source " << source << " to target " << target << "\n";
	        return;
	    }

	    stack<int> path;
	    int current = target;
	    while (current != source) {
	        path.push(current);
	        current = parent[current];
	    }
	    path.push(source);

	    auto [source_g_id, source_n_id] = Galaxy::get_ids(galaxies, source);
	    auto [target_g_id, target_n_id] = Galaxy::get_ids(galaxies, target);


	    cout << "Shortest path from " << source_g_id << '.' << source_n_id << " to " << target_g_id << '.' << target_n_id << ":\n";
	    while (!path.empty()) {
	    	int id_number = path.top(); path.pop();
	    	auto [AS_id, node_id] = Galaxy::get_ids(galaxies, id_number);
	    	cout << AS_id << '.' << node_id;
	        if (!path.empty()) cout << " -> ";
	    }
	    cout << " " << "travel_cost: " << dist[target] << '\n';
	}


	~Universe() = default;
};

namespace IO_management{
	bool loop = true;
	string input = "";
	smatch matches;	
	Universe universe;

	void add_node(){ 
		string AS_id = matches[1];
        string node_id = matches[2];
        bool type = matches[3] == "border";
        universe.add_node(node_id, type, AS_id);
	}

	void add_edge(){ 
		string node_a = matches[1];
        string galaxy_a = matches[2];
        int travel_cost = std::stoi(matches[3]);
        string node_b = matches[4];
        string galaxy_b = matches[5];
        universe.add_edge(galaxy_a, node_a, galaxy_b, node_b, travel_cost);
	}

	void add_galaxy(){
		universe.add_galaxy(matches[1]);
	}

	void show_travel_cost(){ 
		string AS_id_a = matches[1];
        string node_a = matches[2];
        string AS_id_b = matches[3];
        string node_b = matches[4];
        universe.show_travel_cost(AS_id_a, node_a, AS_id_b, node_b);
	}


	void match_input(){
	    std::regex add_edge_pattern(R"(\s*CREATE\s+ROAD\s+\(from_node:\s*(\w+)\s*,\s*from_galaxy:\s*(\w+)\s*,\s*cost:\s*(\w+)\s*,\s*to_node:\s*(\w+)\s*,\s*to_galaxy:\s*(\w+)\s*\)\s*)");
	    std::regex add_node_pattern(R"(\s*CREATE\s*\(\s*Node\s*,\s*AS:\s*(\w+)\s*,\s*\{\s*id:\s*(\w+)\s*,\s*type:\s*(\w+)\s*\}\s*\)\s*)");
	    std::regex add_galaxy_pattern(R"(\s*CREATE\s*\(\s*GALAXY:\s*(\w+)\s*\)\s*)");
	    std::regex show_travel_cost_pattern(R"(\s*SHOW\s*\(\s*GALAXY_start:\s*(\w+)\s*,\s*NODE_START:\s*(\w+)\s*,\s*GALAXY_end:\s*(\w+)\s*,\s*NODE_END:\s*(\w+)\s*\)\s*)");	    

	    if (input=="-help"){
	    	cout << "for end of program enter: " << "exit" << endl;
	    	cout << "for adding galaxy enter the input in format of: " << "CREATE (GALAXY: galaxy_id)" << endl;
	    	cout << "for adding a travel raod enter the input in format of: " << "CREATE ROAD (from_node:node_a , from_galaxy: galaxy_a, cost: travel_cost,  to_node:node_b, to_galaxy: galaxy_b)" << endl;
	    	cout << "for adding node enter the input in format of: " << "CREATE (Node, AS: As_id, {id:node_id, type: t=border or nonborder})" << endl;
	    	cout << "for showing travel cost enter the input in format of: " << "SHOW (GALAXY_start: AS_id_a, NODE_START: node_a, GALAXY_end: AS_id_b, NODE_END: node_b)" << endl;
	    	cout << endl;
	    }
	    else if (input=="exit"){
	    	loop = false;
	    	return;
	    }
	    else if (regex_search(input, matches, add_edge_pattern)) {
	        add_edge();
	    } else if (regex_search(input, matches, add_node_pattern)) {
	        add_node();
	    } else if (std::regex_search(input, matches, add_galaxy_pattern)) {
	        add_galaxy();
	    } else if (std::regex_search(input, matches, show_travel_cost_pattern)) {
	        show_travel_cost();
	    } else {
	        std::cout << "No pattern matched the input, enter -help for commands list." << std::endl;
	    }
	}

	void take_input(){
		getline(cin, input);
		match_input();
		if (loop) take_input();
	}

	void test_input(){
		universe.add_galaxy("galaxy1");
		universe.add_node("node_border1", true, "galaxy1");
		universe.add_node("node_non_border1", false, "galaxy1");

		universe.add_galaxy("galaxy2");
		universe.add_node("node_border2", true, "galaxy2");
		universe.add_node("node_non_border2", false, "galaxy2");
		universe.add_node("node_border22", true, "galaxy2");
		universe.add_node("node_non_border22", false, "galaxy2");

		universe.add_galaxy("galaxy3");
		universe.add_node("node_border3", true, "galaxy3");
		universe.add_node("node_non_border3", false, "galaxy3");


		universe.add_edge("galaxy1", "node_non_border1", "galaxy1", "node_border1", 12);
		universe.add_edge("galaxy1", "node_border1", "galaxy2", "node_border2", 21);

		universe.add_edge("galaxy2", "node_non_border2", "galaxy2", "node_border2", 20);
		universe.add_edge("galaxy2", "node_non_border2", "galaxy2", "node_non_border22", 14);
		universe.add_edge("galaxy2", "node_non_border22", "galaxy2", "node_border22", 15);

		universe.add_edge("galaxy3", "node_border3", "galaxy2", "node_border22", 30);
		universe.add_edge("galaxy3", "node_border3", "galaxy3", "node_non_border3", 30);

		// shorcut edge that allows travel to cost less, can comment the line below and compare results 
		universe.add_edge("galaxy3", "node_border3", "galaxy1", "node_border1", 30);


		universe.show_travel_cost("galaxy1", "node_non_border1", "galaxy3", "node_non_border3");
	}
}