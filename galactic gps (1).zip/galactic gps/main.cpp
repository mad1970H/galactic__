#include "utils/Universe.h"
using namespace IO_management;

int main(){
    take_input();
    // test_input();
	return 0;
}

/* can test an input like this: 
CREATE (GALAXY: galaxy1)
CREATE (GALAXY: galaxy2)
CREATE (Node, AS: galaxy1, {id: node_border1, type: border})
CREATE (Node, AS: galaxy1, {id: node_non_border1, type: nonborder})
CREATE (Node, AS: galaxy2, {id: node_border2, type: border})
CREATE (Node, AS: galaxy2, {id: node_non_border2, type: nonborder})
CREATE ROAD (from_node: node_non_border1, from_galaxy: galaxy1, cost: 20, to_node:node_border1, to_galaxy: galaxy1)
CREATE ROAD (from_node: node_border1, from_galaxy: galaxy1, cost: 23, to_node:node_border2, to_galaxy: galaxy2)
CREATE ROAD (from_node: node_border2, from_galaxy: galaxy2, cost: 24, to_node:node_non_border2, to_galaxy: galaxy2)
SHOW (GALAXY_start: galaxy1, NODE_START: node_non_border1, GALAXY_end: galaxy2, NODE_END: node_non_border2)
*/